package ch.unige.cui.rpg;

public enum PossibleTarget {
	PLAYER, TARGET
}
