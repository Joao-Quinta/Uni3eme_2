package ch.unige.cui.rpg;

public enum RessourceType {
	HEALTH, MANA, RAGE
}
