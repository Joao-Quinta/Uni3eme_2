package ch.unige.cui.rpg;

public interface Item {
    public int getWeight();
}